import {UserService} from "../../services/user.service";
import {User} from "../models/user.model";

@Component({ selector: 'app-user-form', templateUrl: './user-form.component.html' })
export class UserFormComponent {
    user: User = { name: '', email: '' };

    constructor(private service: UserService) {}

    save() {
        this.service.createUser(this.user).subscribe();
    }
}