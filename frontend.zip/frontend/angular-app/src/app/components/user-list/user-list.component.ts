@Component({ selector: 'app-user-list', templateUrl: './user-list.component.html' })
export class UserListComponent implements OnInit {
    users: User[] = [];

    constructor(private service: UserService) {}

    ngOnInit() {
        this.service.getUsers().subscribe(data => this.users = data);
    }

    delete(id: number) {
        this.service.deleteUser(id).subscribe(() => this.ngOnInit());
    }
}