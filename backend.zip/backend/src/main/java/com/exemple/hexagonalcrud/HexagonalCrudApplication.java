package com.exemple.hexagonalcrud;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HexagonalCrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(HexagonalCrudApplication.class, args);
    }
}